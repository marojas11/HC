#Miguel Rojas
#Punto 1b Tarea4


import numpy as np #Importar paquete
a=np.zeros([8,8]) #Declarar matriz



fil=-1  #Posicion fila
col=0 #Posicion columna


i=1

print "PUNTO 1. b) Escriba un programa que haga lo mismo en el sentido en contra de las manecillas del reloj para una matriz cuadrada de 8x8."


for i in range (1,65):
    
    if i<=8:
	fil=fil+1
        
        sal= "0%d" %i 
        a[fil][col]=sal   
    elif i<9:
        col=col+1
        sal="0%d"%i
        a[fil][col]=sal
                
    elif i<=15:
        col=col+1
        a[fil][col]=i
        
    elif i<=22:
        fil=fil-1
        a[fil][col]=i
    elif i<=28:
	col=col-1
	a[fil][col]=i
    elif i<=34:
	fil=fil+1
	a[fil][col]=i
    elif i<=39:
	col=col+1
	a[fil][col]=i
   
    elif i<=44:
	fil=fil-1
	a[fil][col]=i
	
    elif i<=48:
	col=col-1
	a[fil][col]=i
    elif i<=52:
	fil=fil+1
	a[fil][col]=i
    elif i<=55:
	col=col+1
	a[fil][col]=i
    elif i<=58:
	fil=fil-1
	a[fil][col]=i
	
    elif i<=60:
	col=col-1
	a[fil][col]=i
    elif i<=62:
	fil=fil+1
	a[fil][col]=i
    elif i<=63:
	col=col+1
	a[fil][col]=i
    elif i<=64:
	fil=fil-1
	a[fil][col]=i
	
   
for row in a:
    for element in row:
	print '%02d' % element, 
    print "  "

   	
