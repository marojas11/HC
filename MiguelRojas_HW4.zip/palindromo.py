#Miguel Rojas
#Punto 2 Tarea4

archivo= open("wordsEn.txt","r") #Leer archivo
c1=0 #cte 1

c2=0 #cte 2

wc=0 # palabras palindromas

for i in range(109582): #Para las lineas del archivo
       leerarchivo=archivo.readline()
       sin_espacio=leerarchivo.rstrip('\n') #Eliminar Espacios
       sin_enter=sin_espacio.rstrip('\r') # Eliminar caracteres adicionales
       palindromo= sin_enter[::-1] #Creacion de palindromos
       if(palindromo==sin_enter): #Evaluar el palindromo
	      wc+=1
              if(c1==0):
                     c1=1
                     lista=[" "] #Inicializar Lista
                     c2+=1
              if(c1==1):
                     lista.append(sin_enter) #Agregar elementos palindromos
                     c2+=1

file = open("palindromos.txt", "w") #Abrir archivo y concatenar nuevo archivo
for j in range(c2):
       string = lista[j]+"\n"
       file.write(string)


file.close()

print lista 

print "\n Puede revisar el archivo en la carpeta actual con %d palabras" %wc