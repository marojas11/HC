#Miguel Rojas
#Punto 1a Tarea4


import numpy as np #Importar paquete
a=np.zeros([7,7]) #Declarar matriz

fil=0 #Posicion fila

col=-1 #Posicion columna


i=1
print "PUNTO 1. a) Escriba un programa que toma como input un vector con los numeros de 1 a n2 y que los imprima en una matriz cuadrada, de dimensiones 7x7 en espiral en el sentido de las manecillas del reloj. El programa debe imprimir los numeros en pantalla, separados por un espacio. llamelo espiral_reloj.py"

for i in range (1,50): #Recorrido de los numeros
    
    if i<=7:		# Primera linea
        col=col+1	#Aumento en la columna
        
        sal= "0%d" %i # Agregar ceros a la izquierda
        a[fil][col]=sal   # Agregar elemento a la matriz
    elif i<9:
        fil=fil+1
        sal="0%d"%i
        a[fil][col]=sal
                
    elif i<=13:
        fil=fil+1
        a[fil][col]=i
        
    elif i<=19:
        col=col-1
        a[fil][col]=i
    elif i<=24:
	fil=fil-1
	a[fil][col]=i
    elif i<=29:
	col=col+1

	a[fil][col]=i
    elif i<=33:
	fil=fil+1
	a[fil][col]=i
    elif i<=37:
	col=col-1
	a[fil][col]=i
    elif i<=40:
	fil=fil-1
	a[fil][col]=i
    elif i<=43:
	col=col+1
	a[fil][col]=i
    elif i<=45:
	fil=fil+1
	a[fil][col]=i
    elif i<=47:
	col=col-1
	a[fil][col]=i
    elif i<=48:
	fil=fil-1
	a[fil][col]=i
    elif i<=49:
	col=col+1
	a[fil][col]=i

for row in a:				#Para eliminar paréntesis y comas
    for element in row:
	print '%02d' % element, 
    print "  "



      


