#Aqui en el archivo punto tex paso todos los package he inicio el documento
echo \\documentclass{article} >> e.tex
echo \\userpackage[utf8]{inpuntec}>> e.tex
echo \\userpackage{multicol}>> e.tex
echo \\userpackage[T1]{fontenc}>> e.tex
echo \\userpackage{lmodern}>> e2.tex
echo \\userpackage[usenames,dvipsnames,svgnames,table]{xcolor}>> e2.tex
echo \\usepackage{fontspec,xltxtra,xunicode} >> e2.tex
echo \\setmaininfont{Times New Ronman} >> e2.tex
echo \\userpackage[spanish]{babel}>> e2.tex
echo \\begin{document} >>e2.tex
echo \\begin{multicol}{2}>> e2.tex
echo \\begin{description}>> e2.tex

#Aqui lo que hago es remplazar ;; por } para cerar el text de bf para que las palabras esten en negrillas
sed 's/;;/ } /g' laletraa.txt >> l2.txt
sed 's/^/ \\textbf{  /g' l2.txt > l3.txt

#Desde aqui se cambia de numeros del mas de 9 se cambian a color azul y se pasa al archivo l11.txt
sed -r 's/ [0-9]+\. / \\textcolor{blue}{ & }/g' l3.txt > l11.txt
# De aqui se buscan las palabras para que esten en italico

sed 's/adj. / \\textit{ adj. }/g' l11.txt > l12.txt
sed 's/m. / \\textit{ m. }/g' l12.txt > l13.txt

sed 's/tr. / \\textit{ tr. }/g' l13.txt > l14.txt
sed 's/adv. / \\textit{ adv. }/g'  l14.txt > l15.txt
cat e2.tex l15.txt > e.tex

#Se eliminan los archivos que no son necesariosrm l2.txt

rm l3.txt
rm l11.txt
rm l12.txt
rm l13.txt
rm l14.txt

#el 15 esta ya todo listo con los \text ya italicos, de color azul y también con negrillas

#Se finaliza el documento
echo \\end{description} >> e.tex
echo \\end{multicols} >> e.tex
echo \\end{documents} >> e.tex


xelatex e.tex
#Se comprime el latex
