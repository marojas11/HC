#Aqui en el archivo punto tex paso todos los package he inicio el documento

mkdir TAREA3MIGUEL
cd TAREA3MIGUEL
wget https://github.com/jngaravitoc/HerramientasComputacionales/raw/master/Homeworks/2015-10/hw3/laletraa.txt >> a.txt

wget https://raw.githubusercontent.com/jngaravitoc/HerramientasComputacionales/master/Homeworks/2015-10/hw3/lainicial.png

echo \\documentclass{article}>> e.tex
echo \\usepackage[utf8]{inputenc}>> e.tex
echo \\usepackage{graphicx}>> e.tex

echo \\usepackage{lmodern}>> e.tex


echo \\usepackage{multicol}>> e.tex
echo \\usepackage[T1]{fontenc}>> e.tex

echo \\usepackage[rightcaption]{sidecap}>> e.tex
echo \\usepackage{xcolor}>> e.tex
echo \\usepackage[spanish,activeacute]{babel}>>e.tex


echo \\usepackage{wrapfig}>> e.tex
echo \\usepackage{fontspec}>> e.tex
echo \\usepackage{xltxtra}>> e.tex


echo \\begin{document}>> e.tex

echo \\begin{multicols}{2}>> e.tex
echo \\includegraphics[scale=.2]{lainicial}>> e.tex


sed 's/;;/ } /g' laletraa.txt >> 1.txt
sed 's/^/ \\textbf{  /g' 1.txt > 2.txt
sed -r 's/ [0-9]+\. / \\textcolor{blue}{ & }/g' 2.txt > 3.txt
sed 's/adj. / \\textit{ adj. }/g' 3.txt > 4.txt
sed 's/m. / \\textit{ m. }/g' 4.txt > 5.txt
sed 's/tr. / \\textit{ tr. }/g' 5.txt > 6.txt
sed 's/adv. / \\textit{ adv. }/g'  6.txt > 7.tex


cat e.tex  7.tex >> NUEVOARCHIVO.tex
cat e.tex  >> NUEVO.tex
#Se eliminan los archivos que no son necesariosrm l2.txt

rm 1.txt
rm 2.txt
rm 3.txt
rm 4.txt
rm 5.txt
rm 6.txt
rm 7.tex

#el 15 esta ya todo listo con los \text ya italicos, de color azul y también con negrillas

#Se finaliza el documento
echo \\end{multicols} >> NUEVOARCHIVO.tex
echo \\end{multicols} >> NUEVO.tex
echo \\end{document} >> NUEVOARCHIVO.tex
echo \\end{document} >> NUEVO.tex


xelatex NUEVOARCHIVO.tex
#Se comprime el latex
