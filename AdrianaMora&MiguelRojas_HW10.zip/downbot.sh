#--------------------------------------------------------------------------------------
#-----------Taller 10  Herramientas Computacionales------------------------------------
#--------------- Miguel Rojas----------------------------------------------------------
#----------------Adriana Mora----------------------------------------------------------


#Primer recorrido para descargar los archivos 1-9
for i in 1 2 3 4 5 6 7 8 9 
do


wget ftp://ftp.ncbi.nih.gov/genomes/Homo_sapiens/CHR_0$i/hs_alt_CHM1_1.1_chr$i.fa.gz
#Se descomprimen los archivos que se bajaron
gunzip hs_alt_CHM1_1.1_chr$i.fa.gz 

done
#Segundo recorrido para descargar llos archivos 10-22
for i in 10 11 12 13 14 15 16 17 18 19 20 21 22
do
wget ftp://ftp.ncbi.nih.gov/genomes/Homo_sapiens/CHR_$i/hs_alt_CHM1_1.1_chr$i.fa.gz
#Se descomprimen los archivos descargados
gunzip hs_alt_CHM1_1.1_chr$i.fa.gz 
done

